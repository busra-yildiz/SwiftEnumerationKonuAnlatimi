import UIKit

//Enumeration
//konserve ile ilgili işlem veren bir şirkette çalıştığımızı varsayan bir işlem yapalım.

enum KonserveBoyut {
    case kucuk
    case orta
    case buyuk
}

func ucretHesapla(boyut:KonserveBoyut, adet:Int){
    switch boyut {
    case KonserveBoyut.kucuk: print ("fiyat : \(adet * 13 ) TL") // istersek case yanına KonserveBoyut.kucuk bu şekilde yazabiliriz istersek direk .kucuk diyerek. ikisi de aynı şey, . koyarak yazmak işlem sürecimizi hızlandırır, bu yüzden daha çok tercih ederiz
    case .orta : print ("fiyat : \(adet * 24 ) TL")
    case .buyuk : print ("fiyat : \(adet * 45 ) TL")
    }
}
ucretHesapla(boyut: .orta, adet: 100)
